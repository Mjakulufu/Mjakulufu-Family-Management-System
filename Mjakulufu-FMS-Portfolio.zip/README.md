# Mjakulufu Family Management System — Portfolio

Static portfolio website for the Mjakulufu Family Management System.

## Files
- `index.html`
- `style.css`
- `script.js`

## GitHub Pages
Keep `index.html` in the root of the publishing branch, then configure GitHub Pages to deploy from that branch/root folder.
