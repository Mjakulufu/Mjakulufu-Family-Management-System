const nav=document.getElementById("nav"),menu=document.getElementById("menu"),links=document.getElementById("links"),theme=document.getElementById("theme"),year=document.getElementById("year");
window.addEventListener("scroll",()=>nav.classList.toggle("scrolled",scrollY>15));
menu.addEventListener("click",()=>{links.classList.toggle("open");menu.textContent=links.classList.contains("open")?"✕":"☰"});
document.querySelectorAll("#links a").forEach(a=>a.addEventListener("click",()=>{links.classList.remove("open");menu.textContent="☰"}));
const saved=localStorage.getItem("mjakulufu-theme");if(saved==="dark"){document.body.classList.add("dark");theme.textContent="☀"}theme.addEventListener("click",()=>{document.body.classList.toggle("dark");const dark=document.body.classList.contains("dark");theme.textContent=dark?"☀":"☾";localStorage.setItem("mjakulufu-theme",dark?"dark":"light")});
year.textContent=new Date().getFullYear();
const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add("show");observer.unobserve(e.target)}}),{threshold:.12});
document.querySelectorAll(".reveal").forEach(e=>observer.observe(e));
